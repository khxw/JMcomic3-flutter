Waifu2x CUnet 2× model
======================

This package contains the `scale2.0x_model.param` and `scale2.0x_model.bin`
files from the official `models-cunet` directory of
`nihui/waifu2x-ncnn-vulkan`.

Upstream: https://github.com/nihui/waifu2x-ncnn-vulkan

The model files are loaded in the app by NCNN. The comic page itself is not
uploaded or copied outside the device.

The upstream model and implementation are distributed under the MIT License.
See `LICENSE.txt` in this package.
